package Builder;

public class MasalaFries extends Fries{
    public String name(){
        return "Masala Fries";
    }

    public float price(){
        return 50;
    }
}
