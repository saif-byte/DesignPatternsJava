package Builder;

public class MayoFries extends Fries{
    public String name(){
        return "Mayo Fries";
    }

    public float price(){
        return 70;
    }
}
