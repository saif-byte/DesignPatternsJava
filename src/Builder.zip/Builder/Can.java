package Builder;

public class Can implements Packing {
    public String pack(){
        return "can";
    }

}
