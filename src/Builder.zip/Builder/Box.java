package Builder;

public class Box implements Packing {
    public String pack(){
        return "box";
    }
}
