package Builder;

public class ChickenBurger extends Burger {
    public String name(){
        return "Chicken Burger";
    }

    public float price(){
        return 500;
    }

}
